DROP TABLE warehouse;

DROP TABLE district;

DROP TABLE customer;

DROP TABLE history;

DROP TABLE new_orders;

DROP TABLE orders;

DROP TABLE order_line;

DROP TABLE item;

DROP TABLE stock;
